**home-restock-ressuply**

This script will execute the following actions, in the following order:

```md
1. Use Detecting Hidden on char to search for potential thives, and only continue if it gets the sysmsg confirming no one is hidden within the house
2. If you set to also unload misc items (items that dont have a shelf for it), it will unload those items
3. Throw all maps in their respective map tomes (tmaps and resources maps)
4. Drop skill scrolls in the Skill Scroll Tome
5. Drop all types of Aspect Items in the Aspect Item Tome
6. Drop cloths in the Rare Cloths Tome
7. Drop all types of dyes in the Dyes Tome
8. Drop Inscription Runes in the Runes Tomes
9. Use a repair bench if there is one nearby
10. Drop gold in the Bank Deposit Box (or gold container if you chose to use that)
11. Restock Storage Shelf using char
12. Restock Storage Shelf using all pack animals with same noto as char found nearby
13. Restock Resource Stockpile using char
14. Restock Resource Stockpile using all pack animals with same noto as char found nearby
15. Restock Garden Shelf using self
16. Dump magic items into the Magic Item Recycler
17. Ressuply from the storage shelf
```

The reason for this order is to put any reagents first on the shelf so they dont go to the resource stockpile, and only after that ressuply from the storage shelf

## SETUP

There are two setups available for using this script:

### GROUND SETUP (DEFAULT SCRIPT SETUP - RECOMMENDED)

In this setup, you will have all shelfs, containers and tomes secured/locked down in the ground, within 2 tiles of the char. The script will autofind everything based on graphics and hues and unload everything in their respective destination accordingly.

If you can setup your house this way, the only variable you need to configure either:

- **unload_misc_items**
  OR
- **unload_misc_items_in_subcontainer**

When you run the script for the first time, it will ask you where you wanna unload your misc items, and will only ask you again if it cant find the container within 2 tiles of the character, or you delete the variable from Razor.

If you do chose to **unload_misc_items_in_subcontainer**, the script will also ask you for your **main_unload_container** in which the subcontainer should be located.

### CONTAINERS/SUBCONTAINERS SETUP (ALTERATIVE FOR SMALL HOUSES WITH FEW SECURES/LOCKDOWNS)

If you have a small house, or dont have enough secures/lockdowns to use the recommended setup, the script is configurable through some variabels at the CONFIGURATION section which you could set according to your case.
If this is your case, you need to uncomment the following variables _(dont use both of each type, use only 1)_

- **unload_misc_items**
  OR
- **unload_misc_items_in_subcontainer**

- **use_gold_deposit_container**
  OR
- **use_gold_deposit_subcontainer**

- **use_tomes_container**
  OR
- **use_tomes_subcontainer**

Uncommenting (using) any of the **container** options will make the script ask you for:

- A container to unload misc items (skill orbs, MCDs, RMs, etc...)
- A container to unload gold
- A container to look for your Item Tomes

If you choose to use the **subcontainers** instead of ground containers, the script also ask you for your **main_unload_container**, witch it will use to search for all the other containers:

If you use the same container for all of these above, simply select the same container when the script asks you for them and you're good to go

> THE SCRIPT WILL ONLY ASK YOU TO SELECT THOSE CONTAINERS AGAIN IF IT CANT FIND THEM WITHIN 2 TILES OF YOUR CHAR WHEN YOU RUN THE SCRIPT, OTHERWISE IT WILL RE-USE THE SAME CONTAINERS OVER AND OVER AND NOT ASK YOU ANYMORE

## CONFIGURATION

The entire script is configurable through variables at the beginning of the file:

- **object_delay**
  This is the delay that is used to wait for all actions across the script (opening chests, drag and drop, etc...)

- **unload_misc_items**
  Uncomment this variable if you also wanna unload uncategorized misc items, like skill orbs, mcds and RMs

- **use_organizer_agent_for_misc_items**
  Uncomment if you wanna use an organizer agent for dropping misc (uncategorized) items in your misc_items_container
  The main reason for this would be that the organizer agent stacks the items, while the drop in script doesnt

- **use_gold_deposit_container**
  Uncomment if you use a regular container for gold that will be on the ground
- **use_gold_deposit_subcontainer**
  Uncomment if you use a regular container for gold that will be inside the main unload container

- **use_tomes_container**
  Uncomment if you use your Item Tomes inside another container, and not locked down on the ground

> If you choose to use any of the above options, the script will ask you for the respective containers only if you havent set them yet, or whenever it cant find them inside the **main_unload_container** when you run it

#####################################################################################

# PT_BR

Este script vai executar as seguintes ações, na seguinte ordem:

```md
1. Jogar todos os mapas da bag em seus respectivos tomes
2. Jogar Skill Scrolls no tome de scroll
3. Jogar Itens de Aspecto (cores, extratos, phylacteries) no tome de aspecto
4. Jogar tecido no Rare Cloth Tome
5. Jogar tintas (cabelo, fortuniture, carpet) no Dyes Tome
6. Usar a repair bench se encontrar uma perto
7. Jogar ouro no cofre se encontrar ouro na bag e o cofre no chao
8. Restocar a shelf pra jogar os regs do char nela
9. Restocka a shelf com todos os pack animals que encontrar perto do char
10. Restocar a shelf de recurso se encontrar uma perto
11. Restocka a shelf de recurso com todos os pack animals que encontrar perto do char
12. Restocar a shelf de jardin se encontrar uma perto
13. Por fim, dar ressuply na shelf pra reabastecer o char
```

A intenção é permitir que o player chegue em casa do farm e guarde tudo e reabasteça novamente com apenas 1 clique.
Apesar de realizar varias ações, tudo acontece bem rapido, cerca de 1 segundo para executar o script todo.

Para isto funcionar, voce deve deixar todos os containers a até 2 tiles do char
