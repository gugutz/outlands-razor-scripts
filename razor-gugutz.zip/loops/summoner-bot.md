# OUTLANDS SUMMONER BOT

## by gugutz

## FEATURES

- Completely configurable with variables
- Prioritizes keeping char summons always up
- Auto summon different combinations of summons
- Auto meditates
- Auto mushroom
- Auto use pre-configure grimoire spells at their respective cooldown delays (needs configuration)
- Auto extend summons life every X (configurable) minutes
- Auto drain corpses within 10 tiles if char has Spirit Speak
- Auto get new targets to kill
- Auto skin nearby corpses if char has Forensic Eval
- Auto find and uses pack llama to unload char when its heavy
- Auto maintain char buffs:
  - Magic Reflection
  - Reactive Armor
  - Herbal Poultice (needs Taste ID)
  - Campfire Visit (needs Camping)
  - Option to lure mobs closer while killing to make it easier to loot them
