logger level setar erro pra prod
pra dev, seta info ou debug (debug mais completo)

POSTGRES_URL é o endereco local que o docker-compose sobe pra fazer os testes de integracao
API_CLIENT_ID e API_CLIENT_SECRET é pra poder consulta4r as APIS da neoway com credenciais do client
E NEOWAY_URL seria o endereco da API, neste caso vou ter qud botar pra ondemand
