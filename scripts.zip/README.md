# outlands-razor-scripts

This is the repository where i backup all the script i've written for Outlands
