# MINING BOT by gugutz

**Requirements**

```md
- First run far from other friends pack animals
- Uncheck option 'filter repeating system messages' on razor
- Uncheck option 'Auto Stack Ore/Fish/Logs at feet' on razor
```

**Features**

```md
- Detects AFK Captcha Gumps and awaits for user input before continuing
- Auto turns on tracking on start if not already Hunting
- Auto re-equips pickaxe whenever needed
- Informs what color ore is being gathered
- Auto finds all char packies and use them.
- Auto renames packies according to weight ('emptypackie', 'lightpackie', 'fullpackie')
- Detects when a packie is heavy and skips to next packie in list by using the following mathods:
  - finding ores on ground while unloading
  - finding the following resource combinations inside packie:
    - ores >= 900
    - ores >= 800 and ingots >= 1000
    - ores >= 700 and ingots >= 3000
    - ores >= 600 and ingots >= 4000
- Auto grabs ores found on ground
- Option to auto escape tracked PK by going home and unloading (default: on)
- Auto travel home and unload when meets one of the following conditions:
  - all packies are are full
  - detected PK tracking message
- Configurable rune position to use in runetome/runebook to escape home
- Auto monitors and maintain char health (cure poison, heal pots, bandages, mage heals...)
- Autoheals with best skills available (pot > bandage (with timer) > mageheals)
- Option to auto smelt ores (default: on) when:
  - within 2 tiles of player forges (default: on)
  - close to some already catalogued map forges (default: on)
- Option to not smelt colored ores (PKs cant smelt colored ores so makes it hard for them to take your ores)
- Auto use charges from runetome/runebook if char doenst have magery
- Auto detects char weapon skill and equips available weapons to fights mobs in scenario
- Option to make char walk randomly (default: off)
- Option to make char walk to specific diretion (default: off)
- Waits world saves
- Detects when char is resource locked (by failed a previous captcha) and stops script
```

-
